<script>
    
  import App from "../App.svelte";

  let {createGoal} = $props();

</script>

<button onclick={createGoal}>
  Add Goal
</button>

<style>

</style>
